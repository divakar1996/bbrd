package com.nucleus.BRDProgram;

import java.util.Scanner;

public class Reader {
	
	
	
	public void 
}
