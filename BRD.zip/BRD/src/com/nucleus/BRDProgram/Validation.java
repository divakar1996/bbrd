package com.nucleus.BRDProgram;

public class Validation {
	public boolean primaryKeycheck(Arry ) {
		
		return false;
	 
	}
	

}
