package com.nucleus.BRDProgram;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BufferedReader bufferedReader = null;
		String line = null;

		List<CustomerMasterTable> list = new ArrayList<CustomerMasterTable>();
		CustomerMasterTable temp = null;
		try {
			bufferedReader = new BufferedReader(new FileReader("E:\\NSBT\\BRD-File Upload\\Test Cases\\testCase1.txt"));

			try {
				while ((line = bufferedReader.readLine()) != null) {
					String[] token = line.split("~", -1);

					

					/*
					 * temp = new CustomerMasterTable(token[0], token[1], token[2], token[3],
					 * token[4], token[5], token[6], token[7], token[8], token[9], token[10],
					 * token[11], token[12], token[13], token[14], token[15]);
					 * 
					 * list.add(temp);
					 */

					/*--------------VALIDATION-------------------*/

					/*
					 * for (CustomerMasterTable cmt : list) { System.out.println(cmt); }
					 * 
					 * System.out.
					 * println("Rejection Level � Press 1. for R - if Record Level rejection is followed.\r\n"
					 * + "Press 2. for F � if File level rejection is followed."); int n =
					 * scanner.nextInt();
					 * 
					 * ----------------------------------------Validations--------------------------
					 * switch (n) { case 1:
					 * 
					 * break;
					 * 
					 * case 2:
					 * 
					 * break;
					 * 
					 * }
					 * 
					 */
				}
			} catch (IOException e) {

				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			scanner.close();
			try {
				bufferedReader.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}

	}

}
