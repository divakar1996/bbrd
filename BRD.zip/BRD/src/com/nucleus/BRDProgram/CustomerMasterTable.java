package com.nucleus.BRDProgram;

public class CustomerMasterTable {

	// private String customerID;
	private String customerCode;
	private String customerName;
	private String customerAddress1;
	private String customerAddress2;
	private String customerPinCode;
	private String emailAddress;
	private String contactNumber;
	private String primaryContactPerson;
	private String recordStatus;
	private String activeInactiveFlag;
	private String createDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String authorizedDate;
	private String authorizedBy;

	public CustomerMasterTable(String customerCode, String customerName, String customerAddress1,
			String customerAddress2, String customerPinCode, String emailAddress, String contactNumber,
			String primaryContactPerson, String recordStatus, String activeInactiveFlag, String createDate,
			String createdBy, String modifiedDate, String modifiedBy, String authorizedDate, String authorizedBy) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;

		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPinCode = customerPinCode;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.primaryContactPerson = primaryContactPerson;
		this.recordStatus = recordStatus;
		this.activeInactiveFlag = activeInactiveFlag;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}

	@Override
	public String toString() {
		return " [customerCode=" + customerCode + ", customerName=" + customerName + ", customerAddress1="
				+ customerAddress1 + ", customerAddress2=" + customerAddress2 + ", customerPinCode=" + customerPinCode
				+ ", emailAddress=" + emailAddress + ", contactNumber=" + contactNumber + ", primaryContactPerson="
				+ primaryContactPerson + ", recordStatus=" + recordStatus + ", activeInactiveFlag=" + activeInactiveFlag
				+ ", createDate=" + createDate + ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + ", authorizedDate=" + authorizedDate + ", authorizedBy=" + authorizedBy
				+ "]";
	}

}
